import {createContext} from 'react';

const vaccineContext=createContext()

export default vaccineContext;